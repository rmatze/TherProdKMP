package com.matze.therprodkmp

const val SERVER_PORT = 8080